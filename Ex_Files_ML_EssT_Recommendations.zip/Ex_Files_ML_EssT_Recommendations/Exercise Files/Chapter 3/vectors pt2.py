import numpy as np

ratings = np.array([
    5,
    2,
    3,
    3,
    4,
    5,
    5,
    1,
    5,
    1,
    3,
    4
])

ratings = ratings * 2

print(ratings)
